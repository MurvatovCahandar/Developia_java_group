package az.developia.spring_test_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringTestProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
