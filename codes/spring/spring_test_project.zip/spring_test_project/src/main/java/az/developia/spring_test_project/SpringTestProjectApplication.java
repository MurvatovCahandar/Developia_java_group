package az.developia.spring_test_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringTestProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringTestProjectApplication.class, args);
	}

}
